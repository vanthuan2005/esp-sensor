package com.example.chessgame;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;

public class SoundManager {

    public static final int SOUND_NONE = 0;
    public static final int SOUND_MOVE_SELF = 1;
    public static final int SOUND_MOVE_OPPONENT = 2;
    public static final int SOUND_CAPTURE = 3;
    public static final int SOUND_CASTLE = 4;
    public static final int SOUND_PROMOTE = 5;

    private final Context context;
    private SoundPool soundPool;

    private int soundMoveSelf;
    private int soundMoveOpponent;
    private int soundCapture;
    private int soundCheck;
    private int soundCastle;
    private int soundPromote;
    private int soundIllegal;
    private int soundGameStart;
    private int soundGameEnd;
    private int soundGameDraw;
    private int soundGameLose;
    private int soundLowTime;

    public SoundManager(Context context) {
        this.context = context.getApplicationContext();
    }

    public void initSounds() {

        AudioAttributes audioAttributes =
                new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build();

        soundPool =
                new SoundPool.Builder()
                        .setMaxStreams(4)
                        .setAudioAttributes(audioAttributes)
                        .build();

        soundMoveSelf = soundPool.load(context, R.raw.move_self, 1);
        soundMoveOpponent = soundPool.load(context, R.raw.move_opponent, 1);
        soundCapture = soundPool.load(context, R.raw.capture, 1);
        soundCheck = soundPool.load(context, R.raw.move_check, 1);
        soundCastle = soundPool.load(context, R.raw.castle, 1);
        soundPromote = soundPool.load(context, R.raw.promote, 1);
        soundIllegal = soundPool.load(context, R.raw.illegal, 1);
        soundGameStart = soundPool.load(context, R.raw.game_start, 1);
        soundGameEnd = soundPool.load(context, R.raw.game_end, 1);
        soundGameDraw = soundPool.load(context, R.raw.game_draw, 1);
        soundGameLose = soundPool.load(context, R.raw.game_lose, 1);
        soundLowTime = soundPool.load(context, R.raw.tenseconds, 1);
    }

    private void playSound(int soundId) {

        if (soundPool == null || soundId == 0) {
            return;
        }

        soundPool.play(soundId, 1.0f, 1.0f, 1, 0, 1.0f);
    }

    public void playMoveResult(
            int moveSoundEvent,
            boolean isCheck) {

        if (isCheck) {
            playCheck();
            return;
        }

        if (moveSoundEvent == SOUND_MOVE_SELF) {
            playMoveSelf();
        } else if (moveSoundEvent == SOUND_MOVE_OPPONENT) {
            playMoveOpponent();
        } else if (moveSoundEvent == SOUND_CAPTURE) {
            playCapture();
        } else if (moveSoundEvent == SOUND_CASTLE) {
            playCastle();
        } else if (moveSoundEvent == SOUND_PROMOTE) {
            playPromote();
        }
    }

    public void playMoveSelf() {
        playSound(soundMoveSelf);
    }

    public void playMoveOpponent() {
        playSound(soundMoveOpponent);
    }

    public void playCapture() {
        playSound(soundCapture);
    }

    public void playCheck() {
        playSound(soundCheck);
    }

    public void playCastle() {
        playSound(soundCastle);
    }

    public void playPromote() {
        playSound(soundPromote);
    }

    public void playIllegal() {
        playSound(soundIllegal);
    }

    public void playGameStart() {
        playSound(soundGameStart);
    }

    public void playGameEnd() {
        playSound(soundGameEnd);
    }

    public void playGameDraw() {
        playSound(soundGameDraw);
    }

    public void playGameLose() {
        playSound(soundGameLose);
    }

    public void playLowTime() {
        playSound(soundLowTime);
    }

    public void release() {

        if (soundPool != null) {
            soundPool.release();
            soundPool = null;
        }
    }
}
