package com.example.chessgame;

public class Chess {
    public static final int SIDE = 8;
    private int turn;
    private Piece piece1;
    private int [][] game;
    public Chess() {
        game = new int[SIDE][SIDE];
        resetGame();
    }
    public int[][] play(int row, int col, int piece) {
        if (row >=0 && col>=0 &&row<SIDE &&col<SIDE && game[row][col] !=0)
        {
            piece1 = new Piece(row, col, piece, game);
            if(turn==1) {
                if(piece>6){
                    int[][] moves = piece1.possibleMoves();
                    return filterLegalMoves(row, col, moves);
                }


            }
            else{

                if(piece<=6&&piece>0){
                    int[][] moves = piece1.possibleMoves();
                    return filterLegalMoves(row, col, moves);
                }


            }

        }
        return new int[SIDE][SIDE];
    }
    private int[][] filterLegalMoves(int oldRow, int oldCol, int[][] moves) {
        for (int row = 0; row < SIDE; row++) {
            for (int col = 0; col < SIDE; col++) {
                // 2 = normal move, 3 = capture
                if (moves[row][col] == 2 || moves[row][col] == 3) {
                    if (!isLegalMove(oldRow, oldCol, row, col)) {
                        moves[row][col] = 0;
                    }
                }
            }
        }
        return moves;
    }

    public boolean isLegalMove(int oldRow, int oldCol, int newRow, int newCol) {
        int movingPiece = game[oldRow][oldCol];
        int capturedPiece = game[newRow][newCol];

        // Try the move temporarily.
        game[newRow][newCol] = movingPiece;
        game[oldRow][oldCol] = 0;

        // White pieces are 7..12; black pieces are 1..6.
        int side = movingPiece > 6 ? 1 : 2;
        boolean legal = !isKingInCheck(side);

        // Restore original board.
        game[oldRow][oldCol] = movingPiece;
        game[newRow][newCol] = capturedPiece;

        return legal;
    }

    public boolean isKingInCheck(int side) {
        // White king = 12, black king = 6.
        int king = side == 1 ? 12 : 6;
        int kingRow = -1;
        int kingCol = -1;

        for (int row = 0; row < SIDE; row++) {
            for (int col = 0; col < SIDE; col++) {
                if (game[row][col] == king) {
                    kingRow = row;
                    kingCol = col;
                    break;
                }
            }
            if (kingRow != -1) {
                break;
            }
        }

        if (kingRow == -1) {
            return true;
        }

        for (int row = 0; row < SIDE; row++) {
            for (int col = 0; col < SIDE; col++) {
                int p = game[row][col];

                if (p == 0) {
                    continue;
                }

                // White king: attacked by black pieces 1..6.
                if (side == 1 && p >= 1 && p <= 6) {
                    Piece enemy = new Piece(row, col, p, game);
                    int[][] moves = enemy.possibleMoves();

                    if (moves != null && moves[kingRow][kingCol] == 3) {
                        return true;
                    }
                }

                // Black king: attacked by white pieces 7..12.
                if (side == 2 && p >= 7 && p <= 12) {
                    Piece enemy = new Piece(row, col, p, game);
                    int[][] moves = enemy.possibleMoves();

                    if (moves != null && moves[kingRow][kingCol] == 3) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    public int[][] getGame() {
        return game;
    }
    public int[][] upgradeBlackPawn(int row, int col){
        game[row][col]=5;
        return game;
    }
    public int[][] upgradeWhitePawn(int row, int col){
        game[row][col]=11;
        return game;
    }
    public int updateTurn(){
        int currentTurn = turn;
        if(turn==1)
            turn=2;
        else
            turn=1;
        return currentTurn;
    }
    public int whoWon(){
        int winner =0;
        for(int r=0;r<Chess.SIDE;r++)
            for(int c=0;c<Chess.SIDE;c++){
                if(game[r][c]==6){
                    winner = 2;
                    break;
                }
            }
        if(winner!=2)
            return 2;
        winner =0;
        for(int r=0;r<Chess.SIDE;r++)
            for(int c=0;c<Chess.SIDE;c++){
                if(game[r][c]==12){
                    winner = 1;
                    break;
                }
            }
        if(winner!=1)
            return 1;
        return 0;
    }
    public String result(){
       if(whoWon() ==1)
           return "Black won";
        if(whoWon()==2)
            return "White won";
        else if(turn ==1)
            return "White's turn";
        else if(turn==2)
            return "Black's turn";
        else
            return "If you're seeing this, something's gone wrong.";
    }
    public void resetGame() {
        for (int row = 0; row < SIDE; row++) {
            if(row==0) {
                game[row][0] = 2;
                game[row][1] = 3;
                game[row][2] = 4;
                game[row][3] = 5;
                game[row][4] = 6;
                game[row][5] = 4;
                game[row][6] = 3;
                game[row][7] = 2;
            }
            else if (row == 7) {
                game[row][0] = 8;
                game[row][1] = 9;
                game[row][2] = 10;
                game[row][3] = 11;
                game[row][4] = 12;
                game[row][5] = 10;
                game[row][6] = 9;
                game[row][7] = 8;
            }
            else {
                for (int col = 0; col<SIDE;col++) {
                    if (row==1)
                        game[row][col] = 1;
                    else if (row==6)
                        game[row][col] = 7;
                    else
                        game[row][col] = 0;
                }
            }
        }
        turn = 1;
    }
    public int getTurn(){
        return turn;
    }
    public void updateBlackCastleRight(boolean castle){
        piece1.updateBlackCastleRight(castle);
    }
    public void updateBlackCastleLeft(boolean castle){
        piece1.updateBlackCastleLeft(castle);
    }
    public void updateWhiteCastleRight(boolean castle){
        piece1.updateWhiteCastleRight(castle);
    }
    public void updateWhiteCastleLeft(boolean castle){
        piece1.updateWhiteCastleLeft(castle);
    }
}
