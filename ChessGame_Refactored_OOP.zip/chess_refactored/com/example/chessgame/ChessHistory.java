package com.example.chessgame;

import java.util.HashMap;

/** Owns repetition history and the one-level undo snapshot. */
class ChessHistory {
    static class Snapshot {
        final int[][] game;
        final int turn;
        final boolean blackCastleRight, blackCastleLeft, whiteCastleRight, whiteCastleLeft;
        Snapshot(int[][] game, int turn, boolean bcr, boolean bcl, boolean wcr, boolean wcl) {
            this.game = game; this.turn = turn;
            blackCastleRight = bcr; blackCastleLeft = bcl;
            whiteCastleRight = wcr; whiteCastleLeft = wcl;
        }
    }

    private HashMap<String, Integer> positionHistory = new HashMap<>();
    private Snapshot undoSnapshot;
    private HashMap<String, Integer> undoPositionHistory;

    void reset(int[][] game, int turn, boolean bcr, boolean bcl, boolean wcr, boolean wcl) {
        undoSnapshot = null;
        undoPositionHistory = null;
        positionHistory.clear();
        record(game, turn, bcr, bcl, wcr, wcl);
    }

    void saveUndo(int[][] game, int turn, boolean bcr, boolean bcl, boolean wcr, boolean wcl) {
        undoSnapshot = new Snapshot(copyBoard(game), turn, bcr, bcl, wcr, wcl);
        undoPositionHistory = new HashMap<>(positionHistory);
    }

    Snapshot restoreUndo() {
        if (undoSnapshot == null) return null;
        Snapshot result = undoSnapshot;
        positionHistory = new HashMap<>(undoPositionHistory);
        undoSnapshot = null;
        undoPositionHistory = null;
        return result;
    }

    boolean canUndo() { return undoSnapshot != null; }

    void record(int[][] game, int turn, boolean bcr, boolean bcl, boolean wcr, boolean wcl) {
        String key = key(game, turn, bcr, bcl, wcr, wcl);
        Integer count = positionHistory.get(key);
        if (count == null) count = 0;
        positionHistory.put(key, count + 1);
    }

    boolean isFivefold(int[][] game, int turn, boolean bcr, boolean bcl, boolean wcr, boolean wcl) {
        Integer count = positionHistory.get(key(game, turn, bcr, bcl, wcr, wcl));
        return count != null && count >= 5;
    }

    private int[][] copyBoard(int[][] game) {
        int[][] copy = new int[Chess.SIDE][Chess.SIDE];
        for (int r = 0; r < Chess.SIDE; r++)
            for (int c = 0; c < Chess.SIDE; c++) copy[r][c] = game[r][c];
        return copy;
    }

    private String key(int[][] game, int turn, boolean bcr, boolean bcl, boolean wcr, boolean wcl) {
        StringBuilder key = new StringBuilder();
        for (int row = 0; row < Chess.SIDE; row++)
            for (int col = 0; col < Chess.SIDE; col++) key.append(game[row][col]).append(',');
        key.append("T").append(turn);
        key.append("BCR").append(bcr ? 1 : 0);
        key.append("BCL").append(bcl ? 1 : 0);
        key.append("WCR").append(wcr ? 1 : 0);
        key.append("WCL").append(wcl ? 1 : 0);
        return key.toString();
    }
}
